import express from 'express';
import Database from 'better-sqlite3';
import path from 'path';
import { fileURLToPath } from 'url';
import dotenv from 'dotenv';

dotenv.config({ path: '.env.local' });

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const app = express();
app.use(express.json({ limit: '10mb' }));

// ── Database setup ──────────────────────────────────────────────────────────
const DB_PATH = path.join(__dirname, '..', 'curaconnect.db');
const db = new Database(DB_PATH);

db.exec(`
  CREATE TABLE IF NOT EXISTS users (
    id TEXT PRIMARY KEY,
    name TEXT NOT NULL,
    email TEXT UNIQUE NOT NULL,
    password TEXT NOT NULL,
    role TEXT NOT NULL CHECK(role IN ('senior','student')),
    bio TEXT,
    avatar_url TEXT,
    rating REAL DEFAULT 0,
    review_count INTEGER DEFAULT 0,
    joined_date TEXT,
    cura_coins INTEGER DEFAULT 0,
    skills TEXT DEFAULT '[]',
    verified INTEGER DEFAULT 0,
    availability TEXT DEFAULT '[]',
    location TEXT,
    radius INTEGER DEFAULT 5,
    needs TEXT DEFAULT '[]',
    preference TEXT DEFAULT 'change_ok',
    cura_plus INTEGER DEFAULT 0,
    emergency_contact TEXT
  );

  CREATE TABLE IF NOT EXISTS jobs (
    id TEXT PRIMARY KEY,
    title TEXT NOT NULL,
    category TEXT NOT NULL,
    date TEXT NOT NULL,
    location TEXT NOT NULL,
    reward REAL NOT NULL,
    status TEXT NOT NULL DEFAULT 'offen',
    creator_id TEXT NOT NULL,
    assignee_id TEXT,
    applicants TEXT DEFAULT '[]',
    payment_method TEXT NOT NULL,
    senior_rated INTEGER DEFAULT 0,
    student_rated INTEGER DEFAULT 0,
    FOREIGN KEY (creator_id) REFERENCES users(id)
  );
`);

// Seed demo users if empty
const userCount = (db.prepare('SELECT COUNT(*) as c FROM users').get() as any).c;
if (userCount === 0) {
  const seedUsers = [
    { id: 'senior1', name: 'Maria', email: 'maria@test.de', password: 'password', role: 'senior', bio: 'Ich liebe Gartenarbeit und backe gerne Kuchen.', rating: 4.8, review_count: 12, joined_date: 'Seit Jan 2024', cura_coins: 0, avatar_url: 'https://randomuser.me/api/portraits/women/68.jpg' },
    { id: 'student1', name: 'Lukas', email: 'lukas@test.de', password: 'password', role: 'student', bio: 'Student der Informatik. Helfe gerne bei Technik-Problemen.', rating: 4.9, review_count: 24, joined_date: 'Seit Okt 2023', cura_coins: 150, avatar_url: 'https://randomuser.me/api/portraits/men/32.jpg' },
    { id: 'senior2', name: 'Heinz', email: 'heinz@test.de', password: 'password', role: 'senior', bio: 'Technik ist nicht so meins, aber ich erzähle gerne Geschichten.', rating: 5.0, review_count: 3, joined_date: 'Seit Feb 2024', cura_coins: 0, avatar_url: 'https://randomuser.me/api/portraits/men/78.jpg' },
    { id: 'senior3', name: 'Gertrud', email: 'gertrud@test.de', password: 'password', role: 'senior', bio: 'Suche ab und zu Hilfe beim Einkaufen.', rating: 4.5, review_count: 8, joined_date: 'Seit März 2024', cura_coins: 0, avatar_url: 'https://randomuser.me/api/portraits/women/79.jpg' },
    { id: 'senior4', name: 'Werner', email: 'werner@test.de', password: 'password', role: 'senior', bio: 'Brauche Hilfe bei schweren Dingen.', rating: 4.9, review_count: 5, joined_date: 'Seit April 2024', cura_coins: 0, avatar_url: 'https://randomuser.me/api/portraits/men/66.jpg' },
  ];

  const insertUser = db.prepare(`
    INSERT INTO users (id, name, email, password, role, bio, avatar_url, rating, review_count, joined_date, cura_coins)
    VALUES (@id, @name, @email, @password, @role, @bio, @avatar_url, @rating, @review_count, @joined_date, @cura_coins)
  `);
  const seedTx = db.transaction(() => seedUsers.forEach((u) => insertUser.run(u)));
  seedTx();

  const seedJobs = [
    { id: '1', title: 'Rasen mähen im Vorgarten', category: 'Garten', date: 'Morgen, 14:00', location: 'München, Schwabing', reward: 15, status: 'offen', creator_id: 'senior2', assignee_id: null, applicants: '[]', payment_method: 'Kreditkarte' },
    { id: '2', title: 'WLAN am Fernseher einrichten', category: 'Technik', date: 'Heute, 16:00', location: 'München, Maxvorstadt', reward: 20, status: 'vergeben', creator_id: 'senior3', assignee_id: 'student1', applicants: '["student1"]', payment_method: 'SEPA Lastschrift' },
    { id: '3', title: 'Schweren Einkauf tragen', category: 'Einkauf', date: 'Freitag, 10:00', location: 'München, Bogenhausen', reward: 10, status: 'offen', creator_id: 'senior4', assignee_id: null, applicants: '[]', payment_method: 'Rechnung' },
    { id: '4', title: 'Fenster putzen', category: 'Haushalt', date: 'Samstag, 09:00', location: 'München, Haidhausen', reward: 25, status: 'offen', creator_id: 'senior1', assignee_id: null, applicants: '[]', payment_method: 'Bar' },
    { id: '5', title: 'Smartphone erklären', category: 'Technik', date: 'Montag, 15:00', location: 'München, Sendling', reward: 15, status: 'offen', creator_id: 'senior2', assignee_id: null, applicants: '[]', payment_method: 'Kreditkarte' },
    { id: '6', title: 'Begleitung zum Arzt', category: 'Sonstiges', date: 'Mittwoch, 08:30', location: 'München, Giesing', reward: 20, status: 'offen', creator_id: 'senior3', assignee_id: null, applicants: '[]', payment_method: 'SEPA Lastschrift' },
    { id: '7', title: 'Hecke schneiden', category: 'Garten', date: 'Donnerstag, 11:00', location: 'München, Pasing', reward: 30, status: 'offen', creator_id: 'senior4', assignee_id: null, applicants: '[]', payment_method: 'Rechnung' },
  ];

  const insertJob = db.prepare(`
    INSERT INTO jobs (id, title, category, date, location, reward, status, creator_id, assignee_id, applicants, payment_method)
    VALUES (@id, @title, @category, @date, @location, @reward, @status, @creator_id, @assignee_id, @applicants, @payment_method)
  `);
  const jobTx = db.transaction(() => seedJobs.forEach((j) => insertJob.run(j)));
  jobTx();
  console.log('✅ Database seeded with demo data');
}

// ── Helpers ──────────────────────────────────────────────────────────────────
function rowToUser(row: any) {
  if (!row) return null;
  return {
    id: row.id,
    name: row.name,
    email: row.email,
    role: row.role,
    bio: row.bio,
    avatarUrl: row.avatar_url,
    rating: row.rating,
    reviewCount: row.review_count,
    joinedDate: row.joined_date,
    curaCoins: row.cura_coins,
    skills: JSON.parse(row.skills || '[]'),
    verified: Boolean(row.verified),
    availability: JSON.parse(row.availability || '[]'),
    location: row.location,
    radius: row.radius,
    needs: JSON.parse(row.needs || '[]'),
    preference: row.preference,
    curaPlus: Boolean(row.cura_plus),
    emergencyContact: row.emergency_contact,
  };
}

function rowToJob(row: any) {
  if (!row) return null;
  return {
    id: row.id,
    title: row.title,
    category: row.category,
    date: row.date,
    location: row.location,
    reward: row.reward,
    status: row.status,
    creatorId: row.creator_id,
    assigneeId: row.assignee_id,
    applicants: JSON.parse(row.applicants || '[]'),
    paymentMethod: row.payment_method,
    seniorRated: Boolean(row.senior_rated),
    studentRated: Boolean(row.student_rated),
  };
}

// ── Auth routes ───────────────────────────────────────────────────────────────
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  const row = db.prepare('SELECT * FROM users WHERE email = ? AND password = ?').get(email, password);
  if (!row) return res.status(401).json({ error: 'E-Mail oder Passwort falsch.' });
  res.json(rowToUser(row));
});

app.post('/api/auth/register', (req, res) => {
  const { name, email, password, role, avatarUrl } = req.body;
  const exists = db.prepare('SELECT id FROM users WHERE email = ?').get(email);
  if (exists) return res.status(409).json({ error: 'Diese E-Mail wird bereits verwendet.' });

  const id = Date.now().toString();
  db.prepare(`
    INSERT INTO users (id, name, email, password, role, avatar_url, joined_date, cura_coins, verified, cura_plus)
    VALUES (?, ?, ?, ?, ?, ?, ?, 0, 0, 0)
  `).run(id, name, email, password, role, avatarUrl || null, 'Heute');

  const row = db.prepare('SELECT * FROM users WHERE id = ?').get(id);
  res.status(201).json(rowToUser(row));
});

// ── User routes ───────────────────────────────────────────────────────────────
app.get('/api/users', (_req, res) => {
  const rows = db.prepare('SELECT * FROM users').all();
  res.json(rows.map(rowToUser));
});

app.patch('/api/users/:id', (req, res) => {
  const { name, bio, avatarUrl, skills, availability, location, radius, needs, preference, emergencyContact, curaCoins, rating, reviewCount } = req.body;

  const updates: string[] = [];
  const params: any[] = [];

  if (name !== undefined) { updates.push('name = ?'); params.push(name); }
  if (bio !== undefined) { updates.push('bio = ?'); params.push(bio); }
  if (avatarUrl !== undefined) { updates.push('avatar_url = ?'); params.push(avatarUrl); }
  if (skills !== undefined) { updates.push('skills = ?'); params.push(JSON.stringify(skills)); }
  if (availability !== undefined) { updates.push('availability = ?'); params.push(JSON.stringify(availability)); }
  if (location !== undefined) { updates.push('location = ?'); params.push(location); }
  if (radius !== undefined) { updates.push('radius = ?'); params.push(radius); }
  if (needs !== undefined) { updates.push('needs = ?'); params.push(JSON.stringify(needs)); }
  if (preference !== undefined) { updates.push('preference = ?'); params.push(preference); }
  if (emergencyContact !== undefined) { updates.push('emergency_contact = ?'); params.push(emergencyContact); }
  if (curaCoins !== undefined) { updates.push('cura_coins = ?'); params.push(curaCoins); }
  if (rating !== undefined) { updates.push('rating = ?'); params.push(rating); }
  if (reviewCount !== undefined) { updates.push('review_count = ?'); params.push(reviewCount); }

  if (updates.length === 0) return res.status(400).json({ error: 'No fields to update' });

  params.push(req.params.id);
  db.prepare(`UPDATE users SET ${updates.join(', ')} WHERE id = ?`).run(...params);
  const row = db.prepare('SELECT * FROM users WHERE id = ?').get(req.params.id);
  res.json(rowToUser(row));
});

// ── Job routes ────────────────────────────────────────────────────────────────
app.get('/api/jobs', (_req, res) => {
  const rows = db.prepare('SELECT * FROM jobs ORDER BY rowid DESC').all();
  res.json(rows.map(rowToJob));
});

app.post('/api/jobs', (req, res) => {
  const { title, category, date, location, reward, creatorId, paymentMethod } = req.body;
  const id = Date.now().toString();
  db.prepare(`
    INSERT INTO jobs (id, title, category, date, location, reward, status, creator_id, applicants, payment_method)
    VALUES (?, ?, ?, ?, ?, ?, 'offen', ?, '[]', ?)
  `).run(id, title, category, date, location, reward, creatorId, paymentMethod);
  const row = db.prepare('SELECT * FROM jobs WHERE id = ?').get(id);
  res.status(201).json(rowToJob(row));
});

app.patch('/api/jobs/:id', (req, res) => {
  const { status, assigneeId, applicants, date, seniorRated, studentRated } = req.body;

  const updates: string[] = [];
  const params: any[] = [];

  if (status !== undefined) { updates.push('status = ?'); params.push(status); }
  if (assigneeId !== undefined) { updates.push('assignee_id = ?'); params.push(assigneeId); }
  if (applicants !== undefined) { updates.push('applicants = ?'); params.push(JSON.stringify(applicants)); }
  if (date !== undefined) { updates.push('date = ?'); params.push(date); }
  if (seniorRated !== undefined) { updates.push('senior_rated = ?'); params.push(seniorRated ? 1 : 0); }
  if (studentRated !== undefined) { updates.push('student_rated = ?'); params.push(studentRated ? 1 : 0); }

  if (updates.length === 0) return res.status(400).json({ error: 'No fields to update' });

  params.push(req.params.id);
  db.prepare(`UPDATE jobs SET ${updates.join(', ')} WHERE id = ?`).run(...params);
  const row = db.prepare('SELECT * FROM jobs WHERE id = ?').get(req.params.id);
  res.json(rowToJob(row));
});

// ── Gemini proxy (keeps API key server-side) ──────────────────────────────────
app.post('/api/ai/chat', async (req, res) => {
  const { prompt, audioData, mimeType, responseFormat } = req.body;
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return res.status(500).json({ error: 'GEMINI_API_KEY not configured' });

  try {
    const parts: any[] = [];
    if (audioData) parts.push({ inlineData: { data: audioData, mimeType: mimeType || 'audio/webm' } });
    parts.push({ text: prompt });

    const body: any = {
      contents: [{ parts }],
      generationConfig: responseFormat === 'json' ? { responseMimeType: 'application/json' } : {},
    };

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
      { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }
    );

    const data = await response.json() as any;
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '';
    res.json({ text });
  } catch (err) {
    console.error('Gemini proxy error:', err);
    res.status(500).json({ error: 'AI request failed' });
  }
});

app.post('/api/ai/image', async (req, res) => {
  const { imageData, mimeType, prompt } = req.body;
  const apiKey = process.env.GEMINI_API_KEY;
  if (!apiKey) return res.status(500).json({ error: 'GEMINI_API_KEY not configured' });

  try {
    const body = {
      contents: [{ parts: [{ text: prompt }, { inlineData: { data: imageData, mimeType } }] }],
      generationConfig: { responseMimeType: 'application/json' },
    };

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${apiKey}`,
      { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(body) }
    );

    const data = await response.json() as any;
    const text = data.candidates?.[0]?.content?.parts?.[0]?.text || '{}';
    res.json({ text });
  } catch (err) {
    console.error('Gemini image proxy error:', err);
    res.status(500).json({ error: 'AI image request failed' });
  }
});

// ── Static frontend (production) ─────────────────────────────────────────────
const DIST = path.join(__dirname, '..', 'dist');
app.use(express.static(DIST));
app.get('*', (_req, res) => res.sendFile(path.join(DIST, 'index.html')));

const PORT = process.env.PORT || 3001;
app.listen(PORT, () => console.log(`🚀 CuraConnect server running on port ${PORT}`));
